DECK DEAL — SOURCES COMPLÈTES (zip du 2026-10-06)
=================================================
Build de référence : commit ce8a72f « Illustrations + aperçu français dans la collection et le scan ; requêtes d'aperçu
prioritaires sur les lectures de fond Scryfall » (branche main de github.com/BeerDeus/mtgcardshop).
dist/deck-deal.html (748 692 octets) : sha256 4e8793f67760c8e113459ede8ed2a023acfd0a72d72fc2e725e988ddf2242640
→ identique octet pour octet au deck-deal.html publié dans ce commit (vérifié après un rebuild complet).
Documentation fonctionnelle détaillée du produit : README.md (même fichier que dans le dépôt).

1. ARBORESCENCE
---------------
src/                    sources de la PWA (une seule page une fois assemblée)
  core.js edhbin.js cloud.js data.js tasks.js app.js filters.js decks.js dklist.js viewer.js collection.js edh.js
  value.js extras.js alerts.js scan.js builder.js back.js pwa.js push.js main.js   → JS, concaténés DANS CET ORDRE (build.mjs)
  style.css             CSS
  body.html             gabarit HTML (corps de la page)
build.mjs               assemble src/* → dist/deck-deal.html (+ dist/deck-deal.artifact.html, fragment) et recopie src/edhbin.js → edhbin.cjs
dist/deck-deal.html     build de référence (régénéré à chaque build)
proxy.mjs               proxy Node (CardTrader, Firebase, push, EDHREC…) — c'est lui qui est lancé en production (deploy/start.cjs)
firestore.rules         règles Firestore
edhbin.cjs              copie de src/edhbin.js pour les générateurs (écrite par build.mjs)
gen-edhrec.mjs gen-fr-names.mjs gen-vapid.mjs   générateurs (decks EDHREC, noms français, clés VAPID) ; make-icons.mjs : icônes PWA
pwa/                    sw.js (service worker), manifest.webmanifest, icons/  (edh.bin.gz et fr-names.tsv sont générés par GitHub Actions, absents ici)
.github/workflows/      edhrec.yml, fr-names.yml (GitHub Actions ; edhrec.yml n'existait que dans le dépôt de déploiement)
deploy/                 fichiers PROPRES au dépôt de déploiement : package.json (démarrage seul, sans dépendances), start.cjs, .gitignore
package.json, package-lock.json   dépendances de DEV (esbuild, firebase, jsdom) — diffèrent de deploy/package.json
tests (racine)          test*.mjs (Node seul) · *-e2e.mjs, e2e-account.mjs, smoke.mjs (navigateur / jsdom) · e2e-world.mjs (faux monde partagé)
fixtures/               14 photos de cartes synthétiques (scan OCR) ; make-card-fixtures.py les régénère (Python + Pillow)
.tmp/                   fb-entry.mjs (+ fb-shared.js, son bundle) : vrai SDK Firebase servi à e2e-account.mjs
ocr-deps/               package.json/lock : Tesseract (scan-e2e, bench-scan) et web-push (test-push) — hors projet principal
shots*.mjs bench-scan.mjs   captures d'écran / banc d'essai OCR (outils, pas des tests) ; shots/ reçoit les captures
run-tests.sh            lance tous les tests un par un   ·   runall.sh : ancienne liste (chemins de la machine d'origine)

2. PRÉREQUIS
------------
- Node ≥ 22 (développé sous v22.22.0 ; le proxy tourne dès Node 18).
- Build : npm ci   (esbuild 0.28.2, firebase 12.19.0, jsdom 29.1.1). Le build lui-même n'utilise que Node (aucun import tiers).
- Tests navigateur : Playwright 1.56.0 + Chromium (build 1194). Non listé dans package.json (il vivait dans /opt/npm-tools) :
    npm i --no-save playwright@1.56.0 && npx playwright install chromium
- scan-e2e.mjs / bench-scan.mjs : Tesseract (sinon le test s'ignore tout seul) ; test-push.mjs : http_ece (sinon une vérif est sautée) :
    (cd ocr-deps && npm ci)   puis   export TESS_DIR=$PWD/ocr-deps/node_modules WEBPUSH_DIR=$PWD/ocr-deps/node_modules
  (versions : tesseract.js 5.1.1, tesseract.js-core 5.1.1, @tesseract.js-data/eng et fra 1.0.0, web-push 3.6.7, http_ece 1.2.0)

3. BUILD
--------
    npm ci
    node build.mjs            → dist/deck-deal.html  (≈ 713 Ko ; sha256 ci-dessus)
    sha256sum dist/deck-deal.html
Déploiement actuel : cp dist/deck-deal.html <dépôt mtgcardshop>/deck-deal.html (+ proxy.mjs, pwa/sw.js, firestore.rules si modifiés),
commit, git push origin main (Hostinger redéploie tout seul).
Régénérer le bundle Firebase des tests (octet pour octet identique à .tmp/fb-shared.js) :
    node_modules/.bin/esbuild .tmp/fb-entry.mjs --bundle --format=esm --outfile=.tmp/fb-shared.js

4. TESTS
--------
Chemins en dur dans les tests (machine d'origine) : /opt/npm-tools/node_modules/ (Playwright), /opt/pw-browsers/chromium (navigateur),
/home/claude/deckdeal (list-e2e.mjs). Ailleurs, une fois, à la racine du projet :
    PW=$PWD/node_modules/                                                  # dossier contenant playwright
    CHROMIUM=$(node -p "require('playwright').chromium.executablePath()")  # binaire Chromium
    sed -i "s#/opt/npm-tools/node_modules/#$PW#g; s#/opt/pw-browsers/chromium#$CHROMIUM#g; s#/home/claude/deckdeal#$PWD#g" *.mjs
Lancer :
    node test.mjs                 un test précis (exemples : node art-e2e.mjs · node coll-e2e.mjs · node scan-e2e.mjs)
    bash run-tests.sh             tout, un par un (≈ 20 min) → run-tests.out + logs/
    bash run-tests.sh art-e2e.mjs lang-e2e.mjs        une sélection
Ne JAMAIS lancer deux tests en même temps (ports fixes 188xx/189xx) ni rebuilder pendant qu'un test tourne (ils lisent dist/deck-deal.html).
Un test réussi se termine par « … OK » / code 0 ; scan-e2e.mjs dure ≈ 2 min.
Familles :
  Node seul      test.mjs (logique : parseurs, prix, panier…) · test-cloud · test-jobs · test-proxy · test-push · test-alerts · test-edh-gen
  jsdom          smoke.mjs
  Navigateur     ui-e2e · list-e2e · value-e2e · frcat-e2e · alerts-e2e · dklist-e2e · back-e2e · lang-e2e · art-e2e · viewer-e2e
                 builder-e2e · coll-e2e · extras-e2e · edh-e2e · prix-e2e · pwa-e2e · sw-e2e · push-client-e2e · sync-e2e
                 e2e-account (Firebase réel simulé) · scan-e2e (OCR + caméra factice) · live-e2e (proxy réel → faux CardTrader)
Les e2e partagent e2e-world.mjs (faux Scryfall, faux CardTrader, helpers newPage/txt/ok/done) et fixtures/.
