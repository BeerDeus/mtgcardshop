#!/bin/bash
cd /home/claude/deckdeal
for t in test.mjs smoke.mjs coll-e2e.mjs prix-e2e.mjs scan-e2e.mjs pwa-e2e.mjs viewer-e2e.mjs list-e2e.mjs sw-e2e.mjs push-client-e2e.mjs e2e-account.mjs test-cloud.mjs test-jobs.mjs test-proxy.mjs test-push.mjs sync-e2e.mjs frcat-e2e.mjs edh-e2e.mjs value-e2e.mjs test-edh-gen.mjs; do
  s=$(date +%s); timeout 420 node $t > /tmp/log-$t.txt 2>&1; rc=$?; echo "$t rc=$rc $(( $(date +%s)-s ))s" >> /tmp/runall.out
done
echo DONE >> /tmp/runall.out
